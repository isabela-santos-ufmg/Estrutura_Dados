#include "Test.h"

Test::Test() {

}

Test::~Test() {

}

void Test::Print() {
    printf("Test\n");
}