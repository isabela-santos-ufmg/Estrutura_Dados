#ifndef TEST_H
#define TEST_H

#include <stdio.h>

class Test 
{
    public:
        Test();
        ~Test();
        void Print();
};

#endif